package com.example.demo.sentiment_analysis.reaction.reaction_response;

import com.example.demo.sentiment_analysis.reaction.enumeration.ReactionType;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReactionResponseDto {
    private String postId;

    private String userName;

    private ReactionType reactionType;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createdAt;
}
